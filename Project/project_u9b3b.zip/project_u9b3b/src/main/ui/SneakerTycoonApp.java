package ui;

import model.Business;
import model.Clicker;
import ui.menus.CollectionMenu;
import ui.menus.DeveloperMenu;
import ui.menus.MarketplaceMenu;
import ui.menus.UpgradeMenu;

import java.util.Scanner;

/*
 * Represents the main menu in which the Sneaker Tycoon game is played.
 */

public class SneakerTycoonApp extends Menu {

    private Business myBusiness;
    private Clicker clicker;

    public SneakerTycoonApp() {
        runMenu();
    }

    @Override
    protected void init() {
        input = new Scanner(System.in);
        System.out.println("What is the name of your business?");
        myBusiness = new Business(input.nextLine());
        clicker = new Clicker(myBusiness);
        System.out.println("If this is your first time playing, enter \"h\" for some help!");
    }

    @Override
    // EFFECTS: displays the main menu of options
    protected void displayMenu() {
        System.out.println("Welcome to " + myBusiness.getBusinessName() + ", your sneaker-reselling business!");
        System.out.println("Select from: ");
        System.out.println("Click (f)");
        System.out.println("Upgrade (u)");
        System.out.println("My Collection (c)");
        System.out.println("Marketplace (m)");
        System.out.println("Developer Menu (?)");
        System.out.println("Help (h)");
        System.out.println("Quit (q)");
    }

    // MODIFIES: this
    // EFFECTS: processes user command if one of (f, u, c, m), else sends command to secondary method
    @Override
    protected void processMenuCommand(String command) {
        switch (command) {
            case "f":
                click();
                break;
            case "u":
                UpgradeMenu upgradeMenu = new UpgradeMenu(clicker);
                upgradeMenu.runMenu();
                displayMenu();
                break;
            case "c":
                CollectionMenu collectionMenu = new CollectionMenu(myBusiness);
                collectionMenu.runMenu();
                displayMenu();
                break;
            case "m":
                MarketplaceMenu marketplaceMenu = new MarketplaceMenu(myBusiness);
                marketplaceMenu.runMenu();
                displayMenu();
                break;
            default:
                processMenuCommandSecondary(command);
                break;
        }
    }

    // MODIFIES: this
    // EFFECTS: processes user command
    protected void processMenuCommandSecondary(String command) {
        switch (command) {
            case "?":
                DeveloperMenu developerMenu = new DeveloperMenu(myBusiness);
                developerMenu.runMenu();
                displayMenu();
                break;
            case "d":
                displayMenu();
                break;
            case "h":
                printInstructions();
                break;
            default:
                printError();
                break;
        }
    }

    // MODIFIES: this
    // EFFECTS: clicks one time, prints result information.
    private void click() {
        clicker.click();
        System.out.print("You earned $" + clicker.getGainedPerClick() + ". ");
        System.out.print("Your total balance is $" + myBusiness.getBalance() + ". ");
        System.out.println("Enter \"d\" to display the main menu.");
    }

    // EFFECTS: prints out game instructions
    private void printInstructions() {
        System.out.println("Earn money by clicking. (f)");
        System.out.println("Spend your money to upgrade your clicking power. (u)");
        System.out.println("View your collection and sell sneakers for a profit. (c)");
        System.out.println("Shop in a marketplace. Look for good deals and rare shoes! (m)");
        System.out.println("Test the game without actually spending time playing it (?)");
    }
}
