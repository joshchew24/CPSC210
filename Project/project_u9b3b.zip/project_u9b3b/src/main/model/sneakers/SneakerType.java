package model.sneakers;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/*
 * Represents different types of sneakers.
 */

public enum SneakerType {
    STAN_SMITH("Stan Smith", 110, Rarity.COMMON),
    SUPERSTAR("Superstar", 100, Rarity.COMMON),
    AIR_FORCE_1("Air Force 1", 120, Rarity.COMMON),

    AIR_MAX_1("Air Max 1", 170, Rarity.UNCOMMON),
    AIR_MAX_90("Air Max 90", 160, Rarity.COMMON),
    AIR_MAX_97("Air Max 97", 225, Rarity.UNCOMMON),
    NMD_R1("NMD R1", 170, Rarity.UNCOMMON),
    ULTRABOOST_1("Ultraboost 1.0", 250, Rarity.UNCOMMON),

    AIR_JORDAN_1("Air Jordan 1", 225, Rarity.RARE),
    AIR_JORDAN_3("Air Jordan 3", 265, Rarity.RARE),
    AIR_JORDAN_4("Air Jordan 4", 255, Rarity.RARE),
    AIR_JORDAN_11("Air Jordan 11", 295, Rarity.RARE),
    YEEZY_350("Yeezy 350", 300, Rarity.RARE),

    SW_97_1("Sean Wotherspoon Air Max 97/1", 210, Rarity.GRAIL),
    CHICAGO_AIR_JORDAN_1("2015 Chicago Air Jordan 1", 225, Rarity.GRAIL),

    RED_OCTOBER_YEEZY("Nike Air Yeezy 2 Red October", 330, Rarity.LEGENDARY),
    MAG_BTTF("2016 Nike Mags Back to the Future", 1000, Rarity.LEGENDARY);


    private final String label;
    private final float retailPrice;
    private final Rarity rarity;

    // enum constructor
    // EFFECTS: initializes sneaker type with label, retailPrice, marketPrice, rarity
    SneakerType(String label, float retailPrice, Rarity rarity) {
        this.label = label;
        this.retailPrice = retailPrice;
        this.rarity = rarity;
    }


    // EFFECTS: gets SneakerType at index i from given EnumSet
    public static SneakerType get(EnumSet<SneakerType> setOfSneakerTypes, int i) {
        List<SneakerType> workingList = new ArrayList<>(setOfSneakerTypes);
        return workingList.get(i);
    }

    // EFFECTS: returns an EnumSet containing all SneakerTypes
    public static EnumSet<SneakerType> getAllSneakerTypes() {
        return EnumSet.allOf(SneakerType.class);
    }

    // EFFECTS: returns an EnumSet with all SneakerTypes with given rarity
    public static EnumSet<SneakerType> getAllOfRarity(Rarity rarity) {
        // instantiates empty EnumSet
        EnumSet<SneakerType> result = EnumSet.noneOf(SneakerType.class);
        EnumSet<SneakerType> allSneakerTypes = getAllSneakerTypes();
        for (SneakerType s : allSneakerTypes) {
            if (s.getRarity().equals(rarity)) {
                result.add(s);
            }
        }
        return result;
    }


    // getters:

    public float getRetailPrice() {
        return retailPrice;
    }

    public Rarity getRarity() {
        return rarity;
    }

    public String getLabel() {
        return label;
    }


}